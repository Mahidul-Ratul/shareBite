import React, { useEffect, useState } from "react";
import { View, Text, Image, TouchableOpacity, ScrollView, Alert } from "react-native";
import { LinearGradient } from "expo-linear-gradient";
import { Ionicons, MaterialCommunityIcons } from "@expo/vector-icons";
import { supabase } from "../../../../constants/supabaseConfig";
import { useRouter } from "expo-router";

interface DonorProfile {
  id: string;
  fullName: string;
  email: string;
  phoneNumber: string;
  profileImage?: string;
  coverImage?: string;
  address: string;
  donationsCount: number;
  joinedDate: string;
}

const ProfileScreen = () => {
  const [profile, setProfile] = useState<DonorProfile | null>(null);
  const [loading, setLoading] = useState(true);
  const router = useRouter();

  useEffect(() => {
    const fetchProfile = async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (user) {
        const { data, error } = await supabase
          .from("users")
          .select("*")
          .eq("email", user.email)
          .single();

        if (!error) {
          setProfile({
            ...data,
            donationsCount: data.donationsCount || 0,
            joinedDate: new Date(data.created_at).toLocaleDateString(),
          });
        }
      }
      setLoading(false);
    };

    fetchProfile();
  }, []);

  const handleLogout = async () => {
      const { error } = await supabase.auth.signOut();
      if (error) {
        Alert.alert("Error", error.message);
      } else {
        router.push(".././login");
      }
    };
  

  if (loading) return <View className="flex-1 items-center justify-center"><Text>Loading...</Text></View>;
  if (!profile) return <View className="flex-1 items-center justify-center"><Text>No profile found.</Text></View>;

  return (
    <View className="flex-1 bg-gray-50">
      <ScrollView showsVerticalScrollIndicator={false}>
        {/* Cover Section */}
        <View className="h-40 rounded-b-3xl overflow-hidden">
          {/* Cover Image with Gradient Overlay */}
          <Image
            source={profile.coverImage 
              ? { uri: profile.coverImage } 
              : require("@/assets/images/hasi.jpg")}
            className="w-full h-full absolute"
            resizeMode="cover"
          />
          
          <LinearGradient
            colors={['rgba(107, 255, 107, 0.3)', 'rgba(156, 255, 156, 0.3)']}
            className="w-full h-full"
          >
            <TouchableOpacity 
              className="absolute top-4 right-4 p-2 rounded-full bg-black/20"
              onPress={() => {/* Add cover photo upload logic */}}
            >
              <MaterialCommunityIcons name="camera-outline" size={24} color="white" />
            </TouchableOpacity>
          </LinearGradient>
        </View>

        {/* Profile Content */}
        <View className="px-4 -mt-20">
          {/* Profile Header */}
          <View className="items-center mb-6">
            <View className="relative">
              <Image
                source={profile.profileImage 
                  ? { uri: profile.profileImage } 
                  : require("@/assets/images/hasi.jpg")}
                className="w-32 h-32 rounded-full border-4 border-white"
              />
              <TouchableOpacity className="absolute bottom-2 right-2 bg-white p-2 rounded-full shadow">
                <Ionicons name="pencil" size={16} color="#FF5722" />
              </TouchableOpacity>
            </View>

            <Text className="text-2xl font-bold text-gray-800 mt-4">
              {profile.fullName}
            </Text>
            <Text className="text-gray-500 text-base">Food Donor Hero 🦸♂️</Text>
          </View>

          {/* Stats Cards */}
          <View className="flex-row justify-between mb-6">
            <View className="bg-white p-4 rounded-xl shadow-sm w-[48%] items-center">
              <MaterialCommunityIcons name="food-turkey" size={28} color="#FF5722" />
              <Text className="text-2xl font-bold text-gray-800 my-2">
                {profile.donationsCount}
              </Text>
              <Text className="text-gray-500 text-sm">Total Donations</Text>
            </View>

            <View className="bg-white p-4 rounded-xl shadow-sm w-[48%] items-center">
              <MaterialCommunityIcons name="calendar-heart" size={28} color="#FF5722" />
              <Text className="text-2xl font-bold text-gray-800 my-2">
                {profile.joinedDate}
              </Text>
              <Text className="text-gray-500 text-sm">Member Since</Text>
            </View>
          </View>

          {/* Details Card */}
          <View className="bg-white rounded-xl p-4 mb-4 shadow-sm">
            <View className="flex-row items-center space-x-4 py-3 border-b border-gray-100">
              <Ionicons name="mail-outline" size={24} color="#666" />
              <View>
                <Text className="text-gray-400 text-xs">Email</Text>
                <Text className="text-gray-700 text-base">{profile.email}</Text>
              </View>
            </View>

            <View className="flex-row items-center space-x-4 py-3 border-b border-gray-100">
              <Ionicons name="call-outline" size={24} color="#666" />
              <View>
                <Text className="text-gray-400 text-xs">Phone</Text>
                <Text className="text-gray-700 text-base">{profile.phoneNumber}</Text>
              </View>
            </View>

            <View className="flex-row items-center space-x-4 py-3">
              <Ionicons name="location-outline" size={24} color="#666" />
              <View>
                <Text className="text-gray-400 text-xs">Address</Text>
                <Text className="text-gray-700 text-base">{profile.address}</Text>
              </View>
            </View>
          </View>

          {/* Action Buttons */}
          <TouchableOpacity 
            className="mb-4 rounded-xl overflow-hidden"
            onPress={() => router.push("./edit-profile")}
          >
            <LinearGradient 
            
              colors={['#43a047','#43a047']}
              className="py-4 flex-row justify-center items-center bg-green-600"
            >
              <Ionicons name="create-outline" size={20} color="black" />
              <Text className="text-white font-rubik-medium text-lg ml-2">Edit Profile</Text>
            </LinearGradient>
          </TouchableOpacity>
          <TouchableOpacity 
            className="bg-white border border-green-500 py-4 rounded-xl flex-row justify-center items-center"
            onPress={handleLogout}
          >
            <Ionicons name="log-out-outline" size={20} color="black" />
            <Text className="text-black-500 font-rubik-medium text-lg ml-2">Log Out</Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </View>
  );
};

export default ProfileScreen;