import React, { useEffect, useState } from "react";
import {
  View,
  Text,
  TextInput,
  Image,
  TouchableOpacity,
  StyleSheet,
  Alert,
  ScrollView,
  ImageBackground ,
} from "react-native";
import { Ionicons, MaterialIcons } from "@expo/vector-icons";
import { supabase } from "../../../../constants/supabaseConfig";
import { useRouter } from "expo-router";
import BottomNavigation from "../BottomNavigation"; // Ensure this path is correct or create the BottomNavigation component

const DonorDashboard = () => {
  interface Donor {
    id: string;
    fullName: string;
    email: string;
    phoneNumber: string;
    profileImage?: string;
    
    address: string;
  }

  const [donor, setDonor] = useState<Donor[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState("");
  const router = useRouter();

  useEffect(() => {
    const fetchDonor = async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (user) {
        const { data, error } = await supabase
          .from("users")
          .select("*")
          .eq("email", user.email)
          .single();

        if (error) {
          console.error(error);
        } else {
          setDonor([data]);
        }
      }
      setLoading(false);
    };

    fetchDonor();
  }, []);

  if (loading) {
    return (
      <View style={styles.container}>
        <Text>Loading...</Text>
      </View>
    );
  }

  if (!donor) {
    return (
      <View style={styles.container}>
        <Text>No donor information found.</Text>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      {/* Header */}
      <View className="flex-row justify-between items-center px-5 mb-3">
      <View className="flex-row items-center">
        <MaterialIcons name="location-on" size={20} color="#FF5722" />
        <Text className="font-rubik-medium text-sm text-gray-800 ml-1">{donor[0]?.address}</Text>
      </View>
      <TouchableOpacity onPress={() => router.push("./profile")}>
        <Image source={donor[0]?.profileImage ? { uri: donor[0].profileImage } : require("@/assets/images/avatar.png")} className="w-10 h-10 rounded-full" />
      </TouchableOpacity>
      </View>
      {/* Search Bar */}
      <View style={styles.searchBar}>
      <Ionicons name="search" size={20} color="#888" />
      <TextInput
        placeholder="Search Donors"
        style={styles.searchInput}
        value={searchQuery}
        onChangeText={setSearchQuery}
      />
      </View>
      <ScrollView className="flex-1">
      {/* Donate Banner */}
      <ImageBackground 
        // Use require() for local assets
        source={require('@/assets/images/back.jpg')} // Replace with your image URL
        resizeMode="cover"
        className="rounded-lg mx-5 mt-5 overflow-hidden"
      >
        <View className="p-5 bg-black/30"> {/* Semi-transparent overlay */}
          <Text className="font-rubik-bold text-lg text-white">Welcome {donor[0]?.fullName}</Text>
          <Text className="text-white font-rubik mb-3">
            Do you want to help the community by donating unused food?
          </Text>
          <TouchableOpacity
            onPress={() => router.push(".././Donate")}
            className="bg-green-600 py-2 px-4 rounded-lg self-start"
          >
            <Text className="text-white font-bold">Donate Now →</Text>
          </TouchableOpacity>
        </View>
      </ImageBackground>
      {/* Top Donors */}
      <Text className="font-rubik-semibold text-lg mx-5 mt-5">Top donors of the month</Text>
      <ScrollView horizontal showsHorizontalScrollIndicator={false} className="mx-5 mt-3">
        {donor.map((donor) => (
        <TouchableOpacity
          key={donor.id}
          onPress={() => router.push(`./donor/${donor.id}`)}
          className="items-center mr-4"
        >
          <Image source={donor.profileImage ? { uri: donor.profileImage } : require("@/assets/images/avatar.png")} className="w-12 h-12 rounded-full" />
          <Text className="text-sm text-gray-700 font-rubik-light mt-1">{donor.fullName}</Text>
        </TouchableOpacity>
        ))}
      </ScrollView>
      <View className="flex-row justify-between mx-5 mt-5">
        <Text className="font-rubik-semibold text-lg">Featured organizations</Text>
        <TouchableOpacity>
        <Text className="text-orange-500 font-bold">See All</Text>
        </TouchableOpacity>
      </View>
      <View className="mx-5 mt-3 mb-20">
        <View className="bg-orange-100 rounded-lg p-4 shadow-md mb-3">
        <Text className="font-rubik-semibold text-lg">Feeding Bangladesh</Text>
        <Text className="text-sm font-rubik-medium text-gray-600">Feeding Bangladesh is a non-profit social enterprise...</Text>
        <TouchableOpacity>
          <Text className="text-orange-500 font-bold mt-2">Donate →</Text>
        </TouchableOpacity>
        </View>
        <View className="bg-blue-100 rounded-lg p-4 shadow-md">
        <Text className="font-rubik-semibold text-lg">Amar Parivar</Text>
        <Text className="text-sm font-rubik-medium text-gray-600">Amar Parivar is a non-profit organization...</Text>
        <TouchableOpacity>
          <Text className="text-orange-500 font-bold mt-2">Donate →</Text>
        </TouchableOpacity>
        </View>
      </View>
      </ScrollView>
      <TouchableOpacity style={styles.logoutButton} onPress={() => router.push("./profile")}>
      <Text style={styles.logoutText}>Profile</Text>
      </TouchableOpacity>
      {/* Bottom Navigation */}
      <View style={{ position: 'absolute', bottom: 0, left: 0, right: 0 }}>
      <BottomNavigation />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#fff",
    paddingTop: 10,
  },
  searchBar: {
    flexDirection: "row",
    backgroundColor: "#f2f2f2",
    borderRadius: 8,
    padding: 8,
    margin: 10,
    alignItems: "center",
  },
  searchInput: {
    marginLeft: 10,
    flex: 1,
    fontSize: 16,
  },
  card: {
    flexDirection: "row",
    backgroundColor: "#fff",
    padding: 15,
    marginVertical: 5,
    marginHorizontal: 10,
    borderRadius: 10,
    shadowColor: "#000",
    shadowOpacity: 0.1,
    shadowOffset: { width: 0, height: 2 },
    shadowRadius: 4,
    elevation: 3,
    alignItems: "center",
  },
  profileImage: {
    width: 50,
    height: 50,
    borderRadius: 25,
    marginRight: 15,
  },
  cardInfo: {
    flex: 1,
  },
  donorName: {
    fontSize: 16,
    fontWeight: "bold",
  },
  donorDetail: {
    fontSize: 14,
    color: "#555",
  },
  viewButton: {
    backgroundColor: "#FF5722",
    padding: 8,
    borderRadius: 6,
  },
  viewText: {
    color: "white",
    fontWeight: "bold",
  },
  logoutButton: {
    backgroundColor: "#FF5722",
    padding: 12,
    borderRadius: 6,
    marginTop: 20,
    alignItems: "center",
  },
  logoutText: {
    color: "white",
    fontWeight: "bold",
    fontSize: 14,
  },
});

export default DonorDashboard;